import 'dart:io';

class PhotoModel {
  final String id;
  final String originalPath;
  final String? processedPath;
  final DateTime createdAt;
  final DateTime? lastModified;
  final PhotoMetadata metadata;
  final List<Enhancement> appliedEnhancements;
  final ProcessingStatus status;

  PhotoModel({
    required this.id,
    required this.originalPath,
    this.processedPath,
    required this.createdAt,
    this.lastModified,
    required this.metadata,
    this.appliedEnhancements = const [],
    this.status = ProcessingStatus.ready,
  });

  PhotoModel copyWith({
    String? id,
    String? originalPath,
    String? processedPath,
    DateTime? createdAt,
    DateTime? lastModified,
    PhotoMetadata? metadata,
    List<Enhancement>? appliedEnhancements,
    ProcessingStatus? status,
  }) {
    return PhotoModel(
      id: id ?? this.id,
      originalPath: originalPath ?? this.originalPath,
      processedPath: processedPath ?? this.processedPath,
      createdAt: createdAt ?? this.createdAt,
      lastModified: lastModified ?? this.lastModified,
      metadata: metadata ?? this.metadata,
      appliedEnhancements: appliedEnhancements ?? this.appliedEnhancements,
      status: status ?? this.status,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'originalPath': originalPath,
      'processedPath': processedPath,
      'createdAt': createdAt.toIso8601String(),
      'lastModified': lastModified?.toIso8601String(),
      'metadata': metadata.toJson(),
      'appliedEnhancements': appliedEnhancements.map((e) => e.toJson()).toList(),
      'status': status.toString(),
    };
  }

  factory PhotoModel.fromJson(Map<String, dynamic> json) {
    return PhotoModel(
      id: json['id'],
      originalPath: json['originalPath'],
      processedPath: json['processedPath'],
      createdAt: DateTime.parse(json['createdAt']),
      lastModified: json['lastModified'] != null 
          ? DateTime.parse(json['lastModified']) 
          : null,
      metadata: PhotoMetadata.fromJson(json['metadata']),
      appliedEnhancements: (json['appliedEnhancements'] as List)
          .map((e) => Enhancement.fromJson(e))
          .toList(),
      status: ProcessingStatus.values.firstWhere(
        (s) => s.toString() == json['status'],
        orElse: () => ProcessingStatus.ready,
      ),
    );
  }

  bool get hasBeenProcessed => processedPath != null;
  bool get isProcessing => status == ProcessingStatus.processing;
  String get displayPath => processedPath ?? originalPath;
}

class PhotoMetadata {
  final int width;
  final int height;
  final int fileSize;
  final String format;
  final double? aspectRatio;

  PhotoMetadata({
    required this.width,
    required this.height,
    required this.fileSize,
    required this.format,
    this.aspectRatio,
  });

  Map<String, dynamic> toJson() {
    return {
      'width': width,
      'height': height,
      'fileSize': fileSize,
      'format': format,
      'aspectRatio': aspectRatio,
    };
  }

  factory PhotoMetadata.fromJson(Map<String, dynamic> json) {
    return PhotoMetadata(
      width: json['width'],
      height: json['height'],
      fileSize: json['fileSize'],
      format: json['format'],
      aspectRatio: json['aspectRatio'],
    );
  }

  String get resolution => '${width}x${height}';
  String get fileSizeFormatted {
    if (fileSize < 1024) return '${fileSize}B';
    if (fileSize < 1024 * 1024) return '${(fileSize / 1024).toStringAsFixed(1)}KB';
    return '${(fileSize / (1024 * 1024)).toStringAsFixed(1)}MB';
  }
}

enum ProcessingStatus {
  ready,
  processing,
  completed,
  error,
}

enum EnhancementType {
  qualityEnhancement,
  colorCorrection,
  sharpening,
  denoising,
  brightening,
  faceRetouching,
  backgroundRemoval,
  backgroundReplacement,
}

class Enhancement {
  final String id;
  final EnhancementType type;
  final Map<String, dynamic> parameters;
  final DateTime appliedAt;
  final bool isActive;

  Enhancement({
    required this.id,
    required this.type,
    required this.parameters,
    required this.appliedAt,
    this.isActive = true,
  });

  Enhancement copyWith({
    String? id,
    EnhancementType? type,
    Map<String, dynamic>? parameters,
    DateTime? appliedAt,
    bool? isActive,
  }) {
    return Enhancement(
      id: id ?? this.id,
      type: type ?? this.type,
      parameters: parameters ?? this.parameters,
      appliedAt: appliedAt ?? this.appliedAt,
      isActive: isActive ?? this.isActive,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type.toString(),
      'parameters': parameters,
      'appliedAt': appliedAt.toIso8601String(),
      'isActive': isActive,
    };
  }

  factory Enhancement.fromJson(Map<String, dynamic> json) {
    return Enhancement(
      id: json['id'],
      type: EnhancementType.values.firstWhere(
        (t) => t.toString() == json['type'],
      ),
      parameters: json['parameters'],
      appliedAt: DateTime.parse(json['appliedAt']),
      isActive: json['isActive'] ?? true,
    );
  }

  String get displayName {
    switch (type) {
      case EnhancementType.qualityEnhancement:
        return 'Quality Enhancement';
      case EnhancementType.colorCorrection:
        return 'Color Correction';
      case EnhancementType.sharpening:
        return 'Sharpening';
      case EnhancementType.denoising:
        return 'Noise Removal';
      case EnhancementType.brightening:
        return 'Brightening';
      case EnhancementType.faceRetouching:
        return 'Face Retouching';
      case EnhancementType.backgroundRemoval:
        return 'Background Removal';
      case EnhancementType.backgroundReplacement:
        return 'Background Replacement';
    }
  }
}

