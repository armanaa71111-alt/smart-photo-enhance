import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:uuid/uuid.dart';
import '../models/photo_model.dart';

class ImageUtils {
  static const Uuid _uuid = Uuid();

  // Generate unique ID
  static String generateId() {
    return _uuid.v4();
  }

  // Get image metadata
  static Future<PhotoMetadata> getImageMetadata(File imageFile) async {
    try {
      final bytes = await imageFile.readAsBytes();
      final image = img.decodeImage(bytes);
      
      if (image == null) {
        throw Exception('Could not decode image');
      }

      final fileSize = await imageFile.length();
      final format = _getImageFormat(imageFile.path);
      final aspectRatio = image.width / image.height;

      return PhotoMetadata(
        width: image.width,
        height: image.height,
        fileSize: fileSize,
        format: format,
        aspectRatio: aspectRatio,
      );
    } catch (e) {
      throw Exception('Failed to get image metadata: $e');
    }
  }

  // Get image format from file path
  static String _getImageFormat(String filePath) {
    final extension = filePath.toLowerCase().split('.').last;
    switch (extension) {
      case 'jpg':
      case 'jpeg':
        return 'JPEG';
      case 'png':
        return 'PNG';
      case 'bmp':
        return 'BMP';
      case 'tiff':
      case 'tif':
        return 'TIFF';
      case 'webp':
        return 'WebP';
      default:
        return 'Unknown';
    }
  }

  // Resize image
  static Future<File> resizeImage(
    File inputFile,
    String outputPath, {
    int? width,
    int? height,
    bool maintainAspectRatio = true,
  }) async {
    try {
      final bytes = await inputFile.readAsBytes();
      final image = img.decodeImage(bytes);
      
      if (image == null) {
        throw Exception('Could not decode image');
      }

      img.Image resized;
      
      if (maintainAspectRatio) {
        if (width != null && height != null) {
          resized = img.copyResize(image, width: width, height: height);
        } else if (width != null) {
          resized = img.copyResize(image, width: width);
        } else if (height != null) {
          resized = img.copyResize(image, height: height);
        } else {
          resized = image;
        }
      } else {
        resized = img.copyResize(
          image,
          width: width ?? image.width,
          height: height ?? image.height,
        );
      }

      final outputFile = File(outputPath);
      await outputFile.writeAsBytes(img.encodePng(resized));
      
      return outputFile;
    } catch (e) {
      throw Exception('Failed to resize image: $e');
    }
  }

  // Crop image
  static Future<File> cropImage(
    File inputFile,
    String outputPath, {
    required int x,
    required int y,
    required int width,
    required int height,
  }) async {
    try {
      final bytes = await inputFile.readAsBytes();
      final image = img.decodeImage(bytes);
      
      if (image == null) {
        throw Exception('Could not decode image');
      }

      final cropped = img.copyCrop(image, x: x, y: y, width: width, height: height);
      
      final outputFile = File(outputPath);
      await outputFile.writeAsBytes(img.encodePng(cropped));
      
      return outputFile;
    } catch (e) {
      throw Exception('Failed to crop image: $e');
    }
  }

  // Rotate image
  static Future<File> rotateImage(
    File inputFile,
    String outputPath, {
    required double angle,
  }) async {
    try {
      final bytes = await inputFile.readAsBytes();
      final image = img.decodeImage(bytes);
      
      if (image == null) {
        throw Exception('Could not decode image');
      }

      final rotated = img.copyRotate(image, angle: angle);
      
      final outputFile = File(outputPath);
      await outputFile.writeAsBytes(img.encodePng(rotated));
      
      return outputFile;
    } catch (e) {
      throw Exception('Failed to rotate image: $e');
    }
  }

  // Flip image
  static Future<File> flipImage(
    File inputFile,
    String outputPath, {
    bool horizontal = false,
    bool vertical = false,
  }) async {
    try {
      final bytes = await inputFile.readAsBytes();
      final image = img.decodeImage(bytes);
      
      if (image == null) {
        throw Exception('Could not decode image');
      }

      img.Image flipped = image;
      
      if (horizontal) {
        flipped = img.flipHorizontal(flipped);
      }
      
      if (vertical) {
        flipped = img.flipVertical(flipped);
      }
      
      final outputFile = File(outputPath);
      await outputFile.writeAsBytes(img.encodePng(flipped));
      
      return outputFile;
    } catch (e) {
      throw Exception('Failed to flip image: $e');
    }
  }

  // Convert image format
  static Future<File> convertImageFormat(
    File inputFile,
    String outputPath,
    ImageFormat format,
  ) async {
    try {
      final bytes = await inputFile.readAsBytes();
      final image = img.decodeImage(bytes);
      
      if (image == null) {
        throw Exception('Could not decode image');
      }

      Uint8List encodedBytes;
      
      switch (format) {
        case ImageFormat.png:
          encodedBytes = img.encodePng(image);
          break;
        case ImageFormat.jpg:
          encodedBytes = img.encodeJpg(image, quality: 90);
          break;
        case ImageFormat.bmp:
          encodedBytes = img.encodeBmp(image);
          break;
        case ImageFormat.tiff:
          encodedBytes = img.encodeTiff(image);
          break;
      }
      
      final outputFile = File(outputPath);
      await outputFile.writeAsBytes(encodedBytes);
      
      return outputFile;
    } catch (e) {
      throw Exception('Failed to convert image format: $e');
    }
  }

  // Get image thumbnail
  static Future<File> createThumbnail(
    File inputFile,
    String outputPath, {
    int size = 200,
  }) async {
    try {
      final bytes = await inputFile.readAsBytes();
      final image = img.decodeImage(bytes);
      
      if (image == null) {
        throw Exception('Could not decode image');
      }

      final thumbnail = img.copyResize(
        image,
        width: size,
        height: size,
        interpolation: img.Interpolation.average,
      );
      
      final outputFile = File(outputPath);
      await outputFile.writeAsBytes(img.encodePng(thumbnail));
      
      return outputFile;
    } catch (e) {
      throw Exception('Failed to create thumbnail: $e');
    }
  }

  // Calculate image hash for duplicate detection
  static Future<String> calculateImageHash(File imageFile) async {
    try {
      final bytes = await imageFile.readAsBytes();
      final image = img.decodeImage(bytes);
      
      if (image == null) {
        throw Exception('Could not decode image');
      }

      // Simple hash based on image dimensions and average color
      final avgColor = _calculateAverageColor(image);
      final hash = '${image.width}x${image.height}_${avgColor.toRadixString(16)}';
      
      return hash;
    } catch (e) {
      throw Exception('Failed to calculate image hash: $e');
    }
  }

  // Calculate average color of image
  static int _calculateAverageColor(img.Image image) {
    int totalR = 0, totalG = 0, totalB = 0;
    int pixelCount = 0;

    for (int y = 0; y < image.height; y += 10) {
      for (int x = 0; x < image.width; x += 10) {
        final pixel = image.getPixel(x, y);
        totalR += image.getPixel(x, y).r.toInt();
        totalG += image.getPixel(x, y).g.toInt();
        totalB += image.getPixel(x, y).b.toInt();
        pixelCount++;
      }
    }

    if (pixelCount == 0) return 0;

    final avgR = totalR ~/ pixelCount;
    final avgG = totalG ~/ pixelCount;
    final avgB = totalB ~/ pixelCount;

    return (avgR << 16) | (avgG << 8) | avgB;
  }

  // Check if image is landscape or portrait
  static ImageOrientation getImageOrientation(PhotoMetadata metadata) {
    if (metadata.width > metadata.height) {
      return ImageOrientation.landscape;
    } else if (metadata.height > metadata.width) {
      return ImageOrientation.portrait;
    } else {
      return ImageOrientation.square;
    }
  }

  // Get optimal display size for image
  static Size getOptimalDisplaySize(
    PhotoMetadata metadata,
    Size containerSize,
  ) {
    final imageAspectRatio = metadata.aspectRatio ?? 1.0;
    final containerAspectRatio = containerSize.width / containerSize.height;

    if (imageAspectRatio > containerAspectRatio) {
      // Image is wider than container
      return Size(
        containerSize.width,
        containerSize.width / imageAspectRatio,
      );
    } else {
      // Image is taller than container
      return Size(
        containerSize.height * imageAspectRatio,
        containerSize.height,
      );
    }
  }

  // Validate image file
  static bool isValidImageFile(String filePath) {
    final validExtensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'];
    final extension = filePath.toLowerCase().split('.').last;
    return validExtensions.contains('.$extension');
  }

  // Get file extension from path
  static String getFileExtension(String filePath) {
    return filePath.split('.').last.toLowerCase();
  }

  // Generate output filename
  static String generateOutputFilename(
    String originalPath,
    String suffix, {
    String? extension,
  }) {
    final originalName = originalPath.split('/').last.split('.').first;
    final ext = extension ?? getFileExtension(originalPath);
    return '${originalName}_$suffix.$ext';
  }

  // Format file size
  static String formatFileSize(int bytes) {
    if (bytes < 1024) return '${bytes}B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)}KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)}MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)}GB';
  }
}

enum ImageFormat {
  png,
  jpg,
  bmp,
  tiff,
}

enum ImageOrientation {
  landscape,
  portrait,
  square,
}

class Size {
  final double width;
  final double height;

  const Size(this.width, this.height);

  @override
  String toString() => 'Size($width, $height)';
}

