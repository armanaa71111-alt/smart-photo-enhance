import 'dart:io';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:path/path.dart' as path;
import '../models/photo_model.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:8000'; // Change for production
  late final Dio _dio;

  ApiService() {
    _dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(minutes: 5),
      headers: {
        'Content-Type': 'application/json',
      },
    ));

    // Add interceptors for logging and error handling
    _dio.interceptors.add(LogInterceptor(
      requestBody: false,
      responseBody: false,
    ));
  }

  // Health check
  Future<bool> checkHealth() async {
    try {
      final response = await _dio.get('/health');
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // Upload image
  Future<String> uploadImage(File imageFile) async {
    try {
      final fileName = path.basename(imageFile.path);
      final formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(
          imageFile.path,
          filename: fileName,
        ),
      });

      final response = await _dio.post('/upload', data: formData);
      
      if (response.statusCode == 200) {
        return response.data['file_id'];
      } else {
        throw ApiException('Failed to upload image: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Upload failed: ${e.message}');
    }
  }

  // Quality enhancement
  Future<String> enhanceQuality(String fileId, {int scale = 2}) async {
    try {
      final formData = FormData.fromMap({
        'file_id': fileId,
        'scale': scale,
      });

      final response = await _dio.post('/enhance/quality', data: formData);
      
      if (response.statusCode == 200) {
        return response.data['output_filename'];
      } else {
        throw ApiException('Quality enhancement failed: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Quality enhancement failed: ${e.message}');
    }
  }

  // Color correction
  Future<String> correctColors(String fileId) async {
    try {
      final formData = FormData.fromMap({
        'file_id': fileId,
      });

      final response = await _dio.post('/enhance/color', data: formData);
      
      if (response.statusCode == 200) {
        return response.data['output_filename'];
      } else {
        throw ApiException('Color correction failed: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Color correction failed: ${e.message}');
    }
  }

  // Sharpen image
  Future<String> sharpenImage(String fileId, {double strength = 1.0}) async {
    try {
      final formData = FormData.fromMap({
        'file_id': fileId,
        'strength': strength,
      });

      final response = await _dio.post('/enhance/sharpen', data: formData);
      
      if (response.statusCode == 200) {
        return response.data['output_filename'];
      } else {
        throw ApiException('Sharpening failed: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Sharpening failed: ${e.message}');
    }
  }

  // Denoise image
  Future<String> denoiseImage(String fileId) async {
    try {
      final formData = FormData.fromMap({
        'file_id': fileId,
      });

      final response = await _dio.post('/enhance/denoise', data: formData);
      
      if (response.statusCode == 200) {
        return response.data['output_filename'];
      } else {
        throw ApiException('Denoising failed: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Denoising failed: ${e.message}');
    }
  }

  // Brighten image
  Future<String> brightenImage(String fileId, {double factor = 1.5}) async {
    try {
      final formData = FormData.fromMap({
        'file_id': fileId,
        'factor': factor,
      });

      final response = await _dio.post('/enhance/brighten', data: formData);
      
      if (response.statusCode == 200) {
        return response.data['output_filename'];
      } else {
        throw ApiException('Brightening failed: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Brightening failed: ${e.message}');
    }
  }

  // Face retouching
  Future<String> retouchFace(String fileId) async {
    try {
      final formData = FormData.fromMap({
        'file_id': fileId,
      });

      final response = await _dio.post('/enhance/face', data: formData);
      
      if (response.statusCode == 200) {
        return response.data['output_filename'];
      } else {
        throw ApiException('Face retouching failed: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Face retouching failed: ${e.message}');
    }
  }

  // Remove background
  Future<String> removeBackground(String fileId) async {
    try {
      final formData = FormData.fromMap({
        'file_id': fileId,
      });

      final response = await _dio.post('/background/remove', data: formData);
      
      if (response.statusCode == 200) {
        return response.data['output_filename'];
      } else {
        throw ApiException('Background removal failed: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Background removal failed: ${e.message}');
    }
  }

  // Replace background
  Future<String> replaceBackground(
    String fileId,
    File backgroundFile, {
    double blurAmount = 0.0,
    double dimAmount = 0.0,
  }) async {
    try {
      final backgroundFileName = path.basename(backgroundFile.path);
      final formData = FormData.fromMap({
        'file_id': fileId,
        'background_file': await MultipartFile.fromFile(
          backgroundFile.path,
          filename: backgroundFileName,
        ),
        'blur_amount': blurAmount,
        'dim_amount': dimAmount,
      });

      final response = await _dio.post('/background/replace', data: formData);
      
      if (response.statusCode == 200) {
        return response.data['output_filename'];
      } else {
        throw ApiException('Background replacement failed: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Background replacement failed: ${e.message}');
    }
  }

  // Download processed image
  Future<void> downloadImage(String filename, String savePath) async {
    try {
      final response = await _dio.download('/download/$filename', savePath);
      
      if (response.statusCode != 200) {
        throw ApiException('Download failed: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw ApiException('Download failed: ${e.message}');
    }
  }

  // Cleanup files
  Future<void> cleanupFiles(String fileId) async {
    try {
      await _dio.delete('/cleanup/$fileId');
    } on DioException catch (e) {
      // Cleanup failures are not critical
      print('Cleanup warning: ${e.message}');
    }
  }

  // Get download URL for processed image
  String getDownloadUrl(String filename) {
    return '$baseUrl/download/$filename';
  }
}

class ApiException implements Exception {
  final String message;
  
  ApiException(this.message);
  
  @override
  String toString() => 'ApiException: $message';
}

// API Response models
class ApiResponse<T> {
  final bool success;
  final T? data;
  final String? error;

  ApiResponse({
    required this.success,
    this.data,
    this.error,
  });

  factory ApiResponse.success(T data) {
    return ApiResponse(success: true, data: data);
  }

  factory ApiResponse.error(String error) {
    return ApiResponse(success: false, error: error);
  }
}

class UploadResponse {
  final String fileId;
  final String filename;
  final String message;

  UploadResponse({
    required this.fileId,
    required this.filename,
    required this.message,
  });

  factory UploadResponse.fromJson(Map<String, dynamic> json) {
    return UploadResponse(
      fileId: json['file_id'],
      filename: json['filename'],
      message: json['message'],
    );
  }
}

class ProcessingResponse {
  final String fileId;
  final String outputFilename;
  final String message;

  ProcessingResponse({
    required this.fileId,
    required this.outputFilename,
    required this.message,
  });

  factory ProcessingResponse.fromJson(Map<String, dynamic> json) {
    return ProcessingResponse(
      fileId: json['file_id'],
      outputFilename: json['output_filename'],
      message: json['message'],
    );
  }
}

