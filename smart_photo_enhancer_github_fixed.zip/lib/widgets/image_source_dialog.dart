import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/photo_provider.dart';
import '../screens/photo_editor_screen.dart';

class ImageSourceDialog extends ConsumerWidget {
  const ImageSourceDialog({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Select Image Source',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _buildSourceOption(
                  context: context,
                  ref: ref,
                  icon: Icons.camera_alt,
                  title: 'Camera',
                  subtitle: 'Take a new photo',
                  onTap: () => _pickFromCamera(context, ref),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildSourceOption(
                  context: context,
                  ref: ref,
                  icon: Icons.photo_library,
                  title: 'Gallery',
                  subtitle: 'Choose from gallery',
                  onTap: () => _pickFromGallery(context, ref),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSourceOption({
    required BuildContext context,
    required WidgetRef ref,
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  icon,
                  size: 32,
                  color: Theme.of(context).primaryColor,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickFromCamera(BuildContext context, WidgetRef ref) async {
    Navigator.pop(context);
    
    try {
      await ref.read(photoProvider.notifier).pickFromCamera();
      final photoState = ref.read(photoProvider);
      
      if (photoState.currentPhoto != null) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const PhotoEditorScreen(),
          ),
        );
      } else if (photoState.error != null) {
        _showErrorSnackBar(context, photoState.error!);
      }
    } catch (e) {
      _showErrorSnackBar(context, 'Failed to access camera: $e');
    }
  }

  Future<void> _pickFromGallery(BuildContext context, WidgetRef ref) async {
    Navigator.pop(context);
    
    try {
      await ref.read(photoProvider.notifier).pickFromGallery();
      final photoState = ref.read(photoProvider);
      
      if (photoState.currentPhoto != null) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const PhotoEditorScreen(),
          ),
        );
      } else if (photoState.error != null) {
        _showErrorSnackBar(context, photoState.error!);
      }
    } catch (e) {
      _showErrorSnackBar(context, 'Failed to access gallery: $e');
    }
  }

  void _showErrorSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        action: SnackBarAction(
          label: 'OK',
          textColor: Colors.white,
          onPressed: () {},
        ),
      ),
    );
  }
}

