package com.example.smart_photo_enhancer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
