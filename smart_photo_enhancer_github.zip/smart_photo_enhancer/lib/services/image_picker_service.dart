import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/photo_model.dart';
import '../utils/image_utils.dart';

class ImagePickerService {
  final ImagePicker _picker = ImagePicker();

  // Pick image from camera
  Future<File?> pickFromCamera() async {
    try {
      // Check camera permission
      final cameraPermission = await Permission.camera.request();
      if (!cameraPermission.isGranted) {
        throw ImagePickerException('Camera permission denied');
      }

      final XFile? image = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 90,
        maxWidth: 2048,
        maxHeight: 2048,
      );

      return image != null ? File(image.path) : null;
    } catch (e) {
      throw ImagePickerException('Failed to pick image from camera: $e');
    }
  }

  // Pick image from gallery
  Future<File?> pickFromGallery() async {
    try {
      // Check storage permission
      final storagePermission = await Permission.photos.request();
      if (!storagePermission.isGranted) {
        throw ImagePickerException('Storage permission denied');
      }

      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 90,
        maxWidth: 2048,
        maxHeight: 2048,
      );

      return image != null ? File(image.path) : null;
    } catch (e) {
      throw ImagePickerException('Failed to pick image from gallery: $e');
    }
  }

  // Pick multiple images from gallery
  Future<List<File>> pickMultipleFromGallery() async {
    try {
      // Check storage permission
      final storagePermission = await Permission.photos.request();
      if (!storagePermission.isGranted) {
        throw ImagePickerException('Storage permission denied');
      }

      final List<XFile> images = await _picker.pickMultiImage(
        imageQuality: 90,
        maxWidth: 2048,
        maxHeight: 2048,
      );

      return images.map((image) => File(image.path)).toList();
    } catch (e) {
      throw ImagePickerException('Failed to pick multiple images: $e');
    }
  }

  // Show image source selection dialog
  Future<File?> showImageSourceDialog() async {
    // This would typically show a dialog in the UI
    // For now, we'll just return null and let the UI handle the dialog
    return null;
  }

  // Create PhotoModel from picked image
  Future<PhotoModel> createPhotoModel(File imageFile) async {
    try {
      final metadata = await ImageUtils.getImageMetadata(imageFile);
      
      return PhotoModel(
        id: ImageUtils.generateId(),
        originalPath: imageFile.path,
        createdAt: DateTime.now(),
        metadata: metadata,
        status: ProcessingStatus.ready,
      );
    } catch (e) {
      throw ImagePickerException('Failed to create photo model: $e');
    }
  }

  // Validate image file
  bool isValidImageFile(File file) {
    final validExtensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff'];
    final extension = file.path.toLowerCase().split('.').last;
    return validExtensions.contains('.$extension');
  }

  // Get image file size
  Future<int> getImageFileSize(File file) async {
    try {
      return await file.length();
    } catch (e) {
      return 0;
    }
  }

  // Check if file exists
  bool fileExists(String path) {
    return File(path).existsSync();
  }

  // Delete image file
  Future<bool> deleteImageFile(String path) async {
    try {
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // Copy image to app directory
  Future<String> copyImageToAppDirectory(File sourceFile, String appDirectory) async {
    try {
      final fileName = '${DateTime.now().millisecondsSinceEpoch}_${sourceFile.path.split('/').last}';
      final destinationPath = '$appDirectory/$fileName';
      
      await sourceFile.copy(destinationPath);
      return destinationPath;
    } catch (e) {
      throw ImagePickerException('Failed to copy image: $e');
    }
  }

  // Compress image if needed
  Future<File> compressImageIfNeeded(File imageFile, {int maxSizeKB = 2048}) async {
    try {
      final fileSize = await imageFile.length();
      final maxSizeBytes = maxSizeKB * 1024;

      if (fileSize <= maxSizeBytes) {
        return imageFile;
      }

      // Calculate compression quality based on file size
      double quality = (maxSizeBytes / fileSize).clamp(0.1, 1.0);
      
      final XFile? compressedImage = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: (quality * 100).round(),
      );

      return compressedImage != null ? File(compressedImage.path) : imageFile;
    } catch (e) {
      // If compression fails, return original file
      return imageFile;
    }
  }

  // Check available storage space
  Future<bool> hasEnoughStorageSpace({int requiredSpaceMB = 100}) async {
    try {
      // This is a simplified check - in a real app you'd use a plugin
      // to check actual available storage space
      return true;
    } catch (e) {
      return false;
    }
  }

  // Get supported image formats
  List<String> getSupportedFormats() {
    return ['jpg', 'jpeg', 'png', 'bmp', 'tiff'];
  }

  // Check permissions
  Future<Map<String, bool>> checkPermissions() async {
    final cameraStatus = await Permission.camera.status;
    final storageStatus = await Permission.photos.status;

    return {
      'camera': cameraStatus.isGranted,
      'storage': storageStatus.isGranted,
    };
  }

  // Request permissions
  Future<Map<String, bool>> requestPermissions() async {
    final cameraStatus = await Permission.camera.request();
    final storageStatus = await Permission.photos.request();

    return {
      'camera': cameraStatus.isGranted,
      'storage': storageStatus.isGranted,
    };
  }
}

class ImagePickerException implements Exception {
  final String message;
  
  ImagePickerException(this.message);
  
  @override
  String toString() => 'ImagePickerException: $message';
}

