import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/photo_model.dart';
import '../providers/photo_provider.dart';
import '../widgets/ad_banner_widget.dart';

class EnhancementControls extends ConsumerWidget {
  final String? fileId;
  final VoidCallback? onEnhancementApplied;

  const EnhancementControls({
    super.key,
    this.fileId,
    this.onEnhancementApplied,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final photoState = ref.watch(photoProvider);
    final qualityScale = ref.watch(qualityEnhancementScaleProvider);
    final sharpeningStrength = ref.watch(sharpeningStrengthProvider);
    final brighteningFactor = ref.watch(brighteningFactorProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'AI Enhancements',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),

          // Quality Enhancement
          _buildEnhancementCard(
            context: context,
            ref: ref,
            title: 'Quality Enhancement',
            description: 'Enhance image resolution and quality',
            icon: Icons.high_quality,
            color: Colors.blue,
            isProcessing: photoState.isLoading,
            onTap: () => _applyQualityEnhancement(context, ref),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Scale Factor'),
                    Text('${qualityScale}x'),
                  ],
                ),
                Slider(
                  value: qualityScale.toDouble(),
                  min: 2,
                  max: 4,
                  divisions: 2,
                  onChanged: (value) {
                    ref.read(qualityEnhancementScaleProvider.notifier).state = value.round();
                  },
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // Color Correction
          _buildEnhancementCard(
            context: context,
            ref: ref,
            title: 'Color Correction',
            description: 'Auto adjust colors and lighting',
            icon: Icons.color_lens,
            color: Colors.orange,
            isProcessing: photoState.isLoading,
            onTap: () => _applyColorCorrection(context, ref),
          ),

          const SizedBox(height: 12),

          // Sharpening
          _buildEnhancementCard(
            context: context,
            ref: ref,
            title: 'Sharpening',
            description: 'Enhance image details and sharpness',
            icon: Icons.tune,
            color: Colors.purple,
            isProcessing: photoState.isLoading,
            onTap: () => _applySharpening(context, ref),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Strength'),
                    Text('${(sharpeningStrength * 100).round()}%'),
                  ],
                ),
                Slider(
                  value: sharpeningStrength,
                  min: 0.5,
                  max: 2.0,
                  onChanged: (value) {
                    ref.read(sharpeningStrengthProvider.notifier).state = value;
                  },
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // Noise Removal
          _buildEnhancementCard(
            context: context,
            ref: ref,
            title: 'Noise Removal',
            description: 'Remove image noise and grain',
            icon: Icons.cleaning_services,
            color: Colors.green,
            isProcessing: photoState.isLoading,
            onTap: () => _applyDenoising(context, ref),
          ),

          const SizedBox(height: 12),

          // Brightening
          _buildEnhancementCard(
            context: context,
            ref: ref,
            title: 'Low-Light Enhancement',
            description: 'Brighten dark photos',
            icon: Icons.brightness_6,
            color: Colors.amber,
            isProcessing: photoState.isLoading,
            onTap: () => _applyBrightening(context, ref),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Brightness Factor'),
                    Text('${(brighteningFactor * 100).round()}%'),
                  ],
                ),
                Slider(
                  value: brighteningFactor,
                  min: 1.0,
                  max: 3.0,
                  onChanged: (value) {
                    ref.read(brighteningFactorProvider.notifier).state = value;
                  },
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // Face Retouching
          _buildEnhancementCard(
            context: context,
            ref: ref,
            title: 'Face Retouching',
            description: 'Smooth skin, whiten teeth, enhance eyes',
            icon: Icons.face,
            color: Colors.pink,
            isProcessing: photoState.isLoading,
            onTap: () => _applyFaceRetouching(context, ref),
            isPremium: true,
          ),

          const SizedBox(height: 16),

          // Error display
          if (photoState.error != null)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red[200]!),
              ),
              child: Row(
                children: [
                  Icon(Icons.error_outline, color: Colors.red[700]),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      photoState.error!,
                      style: TextStyle(color: Colors.red[700]),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () {
                      ref.read(photoProvider.notifier).clearError();
                    },
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEnhancementCard({
    required BuildContext context,
    required WidgetRef ref,
    required String title,
    required String description,
    required IconData icon,
    required Color color,
    required bool isProcessing,
    required VoidCallback onTap,
    Widget? child,
    bool isPremium = false,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: isProcessing ? null : onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(icon, color: color, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              title,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            if (isPremium) ...[
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.amber,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: const Text(
                                  'PRO',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                        Text(
                          description,
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (isProcessing)
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  else
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 16,
                      color: Colors.grey[400],
                    ),
                ],
              ),
              if (child != null) ...[
                const SizedBox(height: 12),
                child,
              ],
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _applyQualityEnhancement(BuildContext context, WidgetRef ref) async {
    if (fileId == null) return;

    final scale = ref.read(qualityEnhancementScaleProvider);
    await ref.read(photoProvider.notifier).applyEnhancement(
      fileId!,
      EnhancementType.qualityEnhancement,
      parameters: {'scale': scale},
    );
    onEnhancementApplied?.call();
  }

  Future<void> _applyColorCorrection(BuildContext context, WidgetRef ref) async {
    if (fileId == null) return;

    await ref.read(photoProvider.notifier).applyEnhancement(
      fileId!,
      EnhancementType.colorCorrection,
    );
    onEnhancementApplied?.call();
  }

  Future<void> _applySharpening(BuildContext context, WidgetRef ref) async {
    if (fileId == null) return;

    final strength = ref.read(sharpeningStrengthProvider);
    await ref.read(photoProvider.notifier).applyEnhancement(
      fileId!,
      EnhancementType.sharpening,
      parameters: {'strength': strength},
    );
    onEnhancementApplied?.call();
  }

  Future<void> _applyDenoising(BuildContext context, WidgetRef ref) async {
    if (fileId == null) return;

    await ref.read(photoProvider.notifier).applyEnhancement(
      fileId!,
      EnhancementType.denoising,
    );
    onEnhancementApplied?.call();
  }

  Future<void> _applyBrightening(BuildContext context, WidgetRef ref) async {
    if (fileId == null) return;

    final factor = ref.read(brighteningFactorProvider);
    await ref.read(photoProvider.notifier).applyEnhancement(
      fileId!,
      EnhancementType.brightening,
      parameters: {'factor': factor},
    );
    onEnhancementApplied?.call();
  }

  Future<void> _applyFaceRetouching(BuildContext context, WidgetRef ref) async {
    // Show premium dialog for face retouching
    showDialog(
      context: context,
      builder: (context) => PremiumDialog(
        feature: 'Face Retouching',
        onUpgrade: () {
          // Handle premium upgrade
          _showUpgradeOptions(context);
        },
      ),
    );
  }

  void _showUpgradeOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Choose Your Plan',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            _buildPlanOption(
              title: 'Watch Ad',
              subtitle: 'Get 1 free premium enhancement',
              price: 'Free',
              onTap: () {
                Navigator.pop(context);
                _watchAdForPremium(context);
              },
            ),
            const SizedBox(height: 12),
            _buildPlanOption(
              title: 'Monthly Premium',
              subtitle: 'Unlimited premium features',
              price: '\$4.99/month',
              onTap: () {
                Navigator.pop(context);
                _purchasePremium(context, 'monthly');
              },
            ),
            const SizedBox(height: 12),
            _buildPlanOption(
              title: 'Yearly Premium',
              subtitle: 'Best value - Save 50%',
              price: '\$29.99/year',
              onTap: () {
                Navigator.pop(context);
                _purchasePremium(context, 'yearly');
              },
              isRecommended: true,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlanOption({
    required String title,
    required String subtitle,
    required String price,
    required VoidCallback onTap,
    bool isRecommended = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: isRecommended ? Colors.amber : Colors.grey[300]!,
          width: isRecommended ? 2 : 1,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        onTap: onTap,
        title: Row(
          children: [
            Text(title),
            if (isRecommended) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.amber,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text(
                  'RECOMMENDED',
                  style: TextStyle(
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
            ],
          ],
        ),
        subtitle: Text(subtitle),
        trailing: Text(
          price,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  void _watchAdForPremium(BuildContext context) {
    RewardedAdManager.showRewardedAd(
      onRewardEarned: () {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Premium feature unlocked! You can now use face retouching.'),
            backgroundColor: Colors.green,
          ),
        );
      },
      onAdClosed: () {
        // Ad closed
      },
    );
  }

  void _purchasePremium(BuildContext context, String plan) {
    // Handle in-app purchase
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Purchasing $plan plan...'),
        backgroundColor: Colors.blue,
      ),
    );
  }
}

