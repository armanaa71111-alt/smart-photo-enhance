import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import '../models/photo_model.dart';
import '../providers/photo_provider.dart';
import 'photo_editor_screen.dart';

class GalleryScreen extends ConsumerStatefulWidget {
  const GalleryScreen({super.key});

  @override
  ConsumerState<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends ConsumerState<GalleryScreen> {
  String _sortBy = 'date';
  bool _showProcessedOnly = false;

  @override
  Widget build(BuildContext context) {
    final photoList = ref.watch(photoListProvider);
    final filteredPhotos = _getFilteredPhotos(photoList);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gallery'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              setState(() {
                _sortBy = value;
              });
              _sortPhotos();
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'date',
                child: Text('Sort by Date'),
              ),
              const PopupMenuItem(
                value: 'name',
                child: Text('Sort by Name'),
              ),
              const PopupMenuItem(
                value: 'size',
                child: Text('Sort by Size'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Filter options
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: FilterChip(
                    label: const Text('Processed Only'),
                    selected: _showProcessedOnly,
                    onSelected: (selected) {
                      setState(() {
                        _showProcessedOnly = selected;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '${filteredPhotos.length} photos',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),

          // Photo grid
          Expanded(
            child: filteredPhotos.isEmpty
                ? _buildEmptyState()
                : Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: MasonryGridView.count(
                      crossAxisCount: 2,
                      mainAxisSpacing: 8,
                      crossAxisSpacing: 8,
                      itemCount: filteredPhotos.length,
                      itemBuilder: (context, index) {
                        final photo = filteredPhotos[index];
                        return _buildPhotoCard(photo);
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  List<PhotoModel> _getFilteredPhotos(List<PhotoModel> photos) {
    if (_showProcessedOnly) {
      return photos.where((photo) => photo.hasBeenProcessed).toList();
    }
    return photos;
  }

  void _sortPhotos() {
    final notifier = ref.read(photoListProvider.notifier);
    
    switch (_sortBy) {
      case 'date':
        notifier.sortByDate(ascending: false);
        break;
      case 'name':
        // Sort by filename
        break;
      case 'size':
        // Sort by file size
        break;
    }
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.photo_library_outlined,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No photos in gallery',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Start by taking a photo or selecting from your device',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              // Navigate to home screen
              DefaultTabController.of(context)?.animateTo(0);
            },
            icon: const Icon(Icons.add_a_photo),
            label: const Text('Add Photo'),
          ),
        ],
      ),
    );
  }

  Widget _buildPhotoCard(PhotoModel photo) {
    return Card(
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () => _openPhoto(photo),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Photo image
            AspectRatio(
              aspectRatio: photo.metadata.aspectRatio ?? 1.0,
              child: Stack(
                children: [
                  Image.file(
                    File(photo.displayPath),
                    fit: BoxFit.cover,
                    width: double.infinity,
                  ),
                  
                  // Processing status indicator
                  if (photo.isProcessing)
                    Positioned.fill(
                      child: Container(
                        color: Colors.black.withOpacity(0.5),
                        child: const Center(
                          child: CircularProgressIndicator(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),

                  // Enhancement indicators
                  if (photo.appliedEnhancements.isNotEmpty)
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          '${photo.appliedEnhancements.length}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // Photo info
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    photo.metadata.resolution,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    photo.metadata.fileSizeFormatted,
                    style: TextStyle(
                      fontSize: 10,
                      color: Colors.grey[600],
                    ),
                  ),
                  if (photo.appliedEnhancements.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      '${photo.appliedEnhancements.length} enhancement${photo.appliedEnhancements.length > 1 ? 's' : ''}',
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.green[600],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openPhoto(PhotoModel photo) {
    ref.read(photoProvider.notifier).setCurrentPhoto(photo);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const PhotoEditorScreen(),
      ),
    );
  }
}

