import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:photo_view/photo_view.dart';
import 'package:share_plus/share_plus.dart';
import '../models/photo_model.dart';
import '../providers/photo_provider.dart';
import '../widgets/enhancement_controls.dart';
import '../widgets/background_controls.dart';
import '../widgets/processing_overlay.dart';
import '../widgets/before_after_view.dart';

class PhotoEditorScreen extends ConsumerStatefulWidget {
  const PhotoEditorScreen({super.key});

  @override
  ConsumerState<PhotoEditorScreen> createState() => _PhotoEditorScreenState();
}

class _PhotoEditorScreenState extends ConsumerState<PhotoEditorScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  String? _uploadedFileId;
  bool _showBeforeAfter = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _uploadImage();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _uploadImage() async {
    final fileId = await ref.read(photoProvider.notifier).uploadImage();
    if (fileId != null) {
      setState(() {
        _uploadedFileId = fileId;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final photoState = ref.watch(photoProvider);
    final showBeforeAfter = ref.watch(showBeforeAfterProvider);

    if (photoState.currentPhoto == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Photo Editor')),
        body: const Center(
          child: Text('No photo selected'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Photo Editor'),
        actions: [
          IconButton(
            icon: Icon(showBeforeAfter ? Icons.compare : Icons.compare_arrows),
            onPressed: () {
              ref.read(showBeforeAfterProvider.notifier).state = !showBeforeAfter;
            },
          ),
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveImage,
          ),
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: _shareImage,
          ),
        ],
      ),
      body: Column(
        children: [
          // Image preview area
          Expanded(
            flex: 3,
            child: Container(
              width: double.infinity,
              color: Colors.black,
              child: Stack(
                children: [
                  if (showBeforeAfter)
                    BeforeAfterView(photo: photoState.currentPhoto!)
                  else
                    _buildImageView(photoState.currentPhoto!),
                  
                  if (photoState.isLoading)
                    const ProcessingOverlay(),
                ],
              ),
            ),
          ),

          // Controls area
          Expanded(
            flex: 2,
            child: Container(
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 8,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Tab bar
                  TabBar(
                    controller: _tabController,
                    labelColor: Theme.of(context).primaryColor,
                    unselectedLabelColor: Colors.grey,
                    indicatorColor: Theme.of(context).primaryColor,
                    tabs: const [
                      Tab(text: 'Enhance', icon: Icon(Icons.auto_fix_high)),
                      Tab(text: 'Background', icon: Icon(Icons.layers)),
                      Tab(text: 'Export', icon: Icon(Icons.file_download)),
                    ],
                  ),

                  // Tab content
                  Expanded(
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        EnhancementControls(
                          fileId: _uploadedFileId,
                          onEnhancementApplied: _onEnhancementApplied,
                        ),
                        BackgroundControls(
                          fileId: _uploadedFileId,
                          onBackgroundChanged: _onBackgroundChanged,
                        ),
                        _buildExportTab(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageView(PhotoModel photo) {
    return PhotoView(
      imageProvider: FileImage(File(photo.displayPath)),
      backgroundDecoration: const BoxDecoration(color: Colors.black),
      minScale: PhotoViewComputedScale.contained,
      maxScale: PhotoViewComputedScale.covered * 3,
      initialScale: PhotoViewComputedScale.contained,
      heroAttributes: PhotoViewHeroAttributes(tag: photo.id),
    );
  }

  Widget _buildExportTab() {
    final photoState = ref.watch(photoProvider);
    final highQualityExport = ref.watch(highQualityExportProvider);

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Export Settings',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),

          // Quality settings
          SwitchListTile(
            title: const Text('High Quality Export'),
            subtitle: const Text('Export in maximum quality (larger file size)'),
            value: highQualityExport,
            onChanged: (value) {
              ref.read(highQualityExportProvider.notifier).state = value;
            },
          ),

          const SizedBox(height: 16),

          // Export buttons
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _saveImage,
                  icon: const Icon(Icons.save),
                  label: const Text('Save to Gallery'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _shareImage,
                  icon: const Icon(Icons.share),
                  label: const Text('Share'),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Image info
          if (photoState.currentPhoto != null) ...[
            const Text(
              'Image Information',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            _buildInfoRow('Resolution', photoState.currentPhoto!.metadata.resolution),
            _buildInfoRow('File Size', photoState.currentPhoto!.metadata.fileSizeFormatted),
            _buildInfoRow('Format', photoState.currentPhoto!.metadata.format),
            if (photoState.currentPhoto!.appliedEnhancements.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text(
                'Applied Enhancements',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              ...photoState.currentPhoto!.appliedEnhancements.map(
                (enhancement) => Padding(
                  padding: const EdgeInsets.only(left: 16, top: 4),
                  child: Text(
                    '• ${enhancement.displayName}',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
          Text(
            value,
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }

  void _onEnhancementApplied() {
    // Refresh the image view
    setState(() {});
    
    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Enhancement applied successfully!'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _onBackgroundChanged() {
    // Refresh the image view
    setState(() {});
    
    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Background changed successfully!'),
        backgroundColor: Colors.green,
      ),
    );
  }

  Future<void> _saveImage() async {
    try {
      final savedPath = await ref.read(photoProvider.notifier).saveProcessedImage();
      
      if (savedPath != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Image saved to gallery!'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to save image'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error saving image: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _shareImage() async {
    final photoState = ref.read(photoProvider);
    
    if (photoState.currentPhoto?.displayPath != null) {
      try {
        await Share.shareXFiles(
          [XFile(photoState.currentPhoto!.displayPath)],
          text: 'Enhanced with Smart Photo Enhancer',
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error sharing image: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
}

